/*
 * Radio.cpp
 *
 *  Created on: 12 Feb 2017
 *      Author: Kevin
 */
#include "Arduino.h" /* Required to use the arduino libary */
#include "T1.h"
#include "Radio.h"

Radio::Radio() {
	// This is called when the class is created

}

void Radio::init_channels(){
	// Clear Interrupts
	cli();

	// Enable Pin Change Interrupts
	// Pin Change Interrupt 0 [7:0]
	// Pin Change Interrupt 1 [14:8]
	// Pin Change Interrupt 2 [23:16]
		PCICR |= (1 << PCIE0);
		PCICR |= (0 << PCIE1);
		PCICR |= (1 << PCIE2);

		// Clear all PCINTs
		PCMSK0 = 0;
		PCMSK1 = 0;
		PCMSK2 = 0;

		//Enable Specific Pins
		PCMSK2 |= (1 << PCINT18);	// THRO - PIN2
		PCMSK2 |= (1 << PCINT20);	// ALIE - PIN4
		PCMSK2 |= (1 << PCINT23);	// ELEV - PIN7
		PCMSK0 |= (1 << PCINT0);	// RUDD - PIN8
		PCMSK0 |= (1 << PCINT1);	// GEAR - PIN9
		PCMSK0 |= (1 << PCINT2);	// AUX1 - PIN10


		// Enable Interrupts
		sei();

}

/* Raw Updated from ISR Called in ISR */
// REturn is in ticks where tick period = 0.5us
	// CHANNEL 1 : THROTTLE	==================================================
	// PCINT18	PIN2	PD2
	uint16_t Radio::read_raw_THRO(){
		//Input changed from 0 to 1 (Rising Edge)
		if(last_channel_value_THRO == 0 && (PIND & B00000100) ){
			rise_time_THRO = get_count_t1();
			last_channel_value_THRO = 1;        //Remember current input state
			}
		//Input changed from 1 to 0 (Falling Edge)
		else if(last_channel_value_THRO == 1 && !(PIND & B00000100)){
			fall_time_THRO = get_count_t1();
			last_channel_value_THRO = 0; //Remember current input state
			THRO_pulse_width = fall_time_THRO - rise_time_THRO;
		}
	return THRO_pulse_width;
}

	// CHANNEL 2 : ALIERON	 ==================================================
	// PCINT20	PIN4	PD4
	uint16_t Radio::read_raw_ALIE(){
		//Input changed from 0 to 1 (Rising Edge)
		if(last_channel_value_ALIE == 0 && (PIND & B00010000) ){
			rise_time_ALIE = get_count_t1();
			last_channel_value_ALIE = 1;        //Remember current input state
			}
		//Input changed from 1 to 0 (Falling Edge)
		else if(last_channel_value_ALIE == 1 && !(PIND & B00010000)){
			fall_time_ALIE = get_count_t1();
			last_channel_value_ALIE = 0; //Remember current input state
			ALIE_pulse_width = fall_time_ALIE - rise_time_ALIE;
			}
		return ALIE_pulse_width;
	}


	// CHANNEL 3 : ELEVATOR	==================================================
	// PCINT23	PIN7	PD7
	uint16_t Radio::read_raw_ELEV(){
		//Input changed from 0 to 1 (Rising Edge)
		if(last_channel_value_ELEV == 0 && (PIND & B10000000) ){
			rise_time_ELEV = get_count_t1();
			last_channel_value_ELEV = 1;        //Remember current input state
			}
		//Input changed from 1 to 0 (Falling Edge)
		else if(last_channel_value_ELEV == 1 && !(PIND & B10000000)){
			fall_time_ELEV = get_count_t1();
			last_channel_value_ELEV = 0; //Remember current input state
			ELEV_pulse_width = fall_time_ELEV - rise_time_ELEV;
			}
		return ELEV_pulse_width;
	}

	// CHANNEL 4 : RUDDER	==================================================
	// PCINT0	PIN8	PB0
	uint16_t Radio::read_raw_RUDD(){
		//Input changed from 0 to 1 (Rising Edge)
		if(last_channel_value_RUDD == 0 && (PINB & B00000001) ){
			rise_time_RUDD = get_count_t1();
			last_channel_value_RUDD = 1;        //Remember current input state
			}
		//Input changed from 1 to 0 (Falling Edge)
		else if(last_channel_value_RUDD == 1 && !(PINB & B00000001)){
			fall_time_RUDD = get_count_t1();
			last_channel_value_RUDD = 0; //Remember current input state
			RUDD_pulse_width = fall_time_RUDD - rise_time_RUDD;
			}
		return RUDD_pulse_width;
	}


	// CHANNEL 5 : GEAR	==================================================
	// PCINT1	PIN9	PB1
	uint16_t Radio::read_raw_GEAR(){
		//Input changed from 0 to 1 (Rising Edge)
			if(last_channel_value_GEAR == 0 && (PINB & B00000010) ){
				rise_time_GEAR = get_count_t1();
				last_channel_value_GEAR = 1;        //Remember current input state
				}
			//Input changed from 1 to 0 (Falling Edge)
			else if(last_channel_value_GEAR == 1 && !(PINB & B00000010)){
				fall_time_GEAR = get_count_t1();
				last_channel_value_GEAR = 0; //Remember current input state
				GEAR_pulse_width = fall_time_GEAR - rise_time_GEAR;
				}
			return GEAR_pulse_width;
	}


	// CHANNEL 6 : AUX1	==================================================
	// PCINT2	PIN10	PB2
	uint16_t Radio::read_raw_AUX1(){
		//Input changed from 0 to 1 (Rising Edge)
			if(last_channel_value_AUX1 == 0 && (PINB & B00000100) ){
				rise_time_AUX1 = get_count_t1();
				last_channel_value_AUX1 = 1;        //Remember current input state
				}
			//Input changed from 1 to 0 (Falling Edge)
			else if(last_channel_value_AUX1 == 1 && !(PINB & B00000100)){
				fall_time_AUX1 = get_count_t1();
				last_channel_value_AUX1 = 0; //Remember current input state
				AUX1_pulse_width = fall_time_AUX1 - rise_time_AUX1;
				}
			return AUX1_pulse_width;
	}

/* Scaled */
// Scaled 0 to 100 for THRO, ALIE, ELEV and RUDD scaled -100 to 100, GEAR and AUX1 scaled 0 to 1
// Assuming uniform pulse width 1000-2000ms
// Trim can be handle on the Radio controller

	// 0 - 100
	float Radio::THRO(){
		float val = THRO_pulse_width * 0.5; // Convert ticks to ms

		// Scale to 0 - 100
		val = (val - 1000) / 10;

		// Ensure val cannot be less than 0
		if (val <= 0){
		return 	0;
		}
		// Ensure val cannot be greater than 100
		else if (val >= 100){
			return 100;
		}
		else
			return val;

	}

	// -100 - 100
	float Radio::ALIE(){
		float val = ALIE_pulse_width * 0.5;

		// Note 10% deadband around centre
		// Direction: Left (-tve)
		if (val > 1510 && val < 2000){
			val = (1510 - val) / 4.9;
			return val;
		}

		// Directoin: Right (+tve)
		else if (val < 1490 && val > 1000){
			val = (1490 - val) / 4.9;
			return val;
		}
		else

		return 	0;
	}

	// -100 - 100
	float Radio::ELEV(){
		float val = ELEV_pulse_width * 0.5;

		// Direction: Forward (+tve)
		if (val > 1510 && val < 2000){
			val = (val - 1510) / 4.9;
			return val;
		}

		// Direction: Backward (-tve)
		else if (val < 1490 && val > 1000){
			val = (val - 1490) / 4.9;
			return val;
		}
		else

		return 	0;

	}

	//-100 - 100
	float Radio::RUDD(){
		float val = RUDD_pulse_width * 0.5;

		// Direction: Left (-tve)
		if (val > 1510 && val < 2000){
			val = (1510 - val) / 4.9;
			return val;
		}

		// Directoin: Right (+tve
		else if (val < 1490 && val > 1000){
			val = (1490 - val) / 4.9;
			return val;
		}
		else

		return 	0;
	}

	// 0 to 1
	uint8_t Radio::GEAR(){
		uint8_t val;
		if(GEAR_pulse_width >3000){
			return 	val = 1;
		}
		else
			return val = 0;
	}

	// 0 to 1
	uint8_t Radio::AUX1(){
		uint8_t val;
		if (AUX1_pulse_width > 3000){
			return 	val = 1;
			}
		else
			return val = 0;
	}


	uint8_t Radio::TH_CUT(){
		float val = THRO_pulse_width * 0.5; // Convert ticks to ms
		if (val < 900){
			return 1;
		}
		else
			return 0;

	}
