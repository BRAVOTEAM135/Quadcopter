/*
 * Source File Rules:
 * ------------------
 * - Constants MUST be defined with capitals. E.g #define VALUE 10
 * - Functions MUST follow the following standard. E.g. adc_init(), adc_write()
 * - Variables Must follow the following standard. E.g. adcValueX, adcValueY
 * - Call by reference for variables. E.g.
 *
 * int a = 100;
 * int b = 200;
 * 
 * swap(&a, &b); //pass variable address in
 * 
 * Where
 * void swap(int *x, int *y){ // using the address will point to value (*x)
 * 	int temp;
 * 	temp = *x;
 * 	*x = *y;
 * 	*y = temp;
 * }
 * }
 * 
 * Source File Comments:
 * ---------------------
 * Provides a tick with 0.5us period
 * 2MHz clock due to the prescaler
 * 
 */

/*----- #include -----*/
 #include "Arduino.h" /* Required to use the arduino libary */
#include "T1.h"


/*----- Constants (#define) -----*/



/*----- (Module) Local Variables (Static) -----*/
volatile uint32_t T1_overflow_count = 0;	//Holds the count for how many timers timer has overflowed
volatile int32_t T1_timer = 0;



/*----- Local Function -----*/
/* Interrupt Service Routine */
// This is called every 1ms
ISR(TIMER1_COMPA_vect){
	//PORTB = PORTB ^ B00100000; // DEBUG
	T1_overflow_count++;

	// Increment Task Counters
/*
	 task_0_count++; // Heart beat on pin 13
	 task_1_count++;
	 task_2_count++;
	 task_3_count++;
*/
}



/*----- Global Functions -----*/
// 16bit Counter. Ticks every 0.5us, Generate ISR every 1ms
void init_t1(){
	cli(); //Disable all interrupts

	// Initialize the Overflow counter variable
	T1_overflow_count = 0;

	// Clear Registers
	TCCR1A = 0;
	TCCR1B = 0;

	// TCCR1 - set WGM waveform generation mode
	// Fast PWM
	// TOP = OCR1A
	TCCR1A |= (1 << WGM10);
	TCCR1A |= (1 << WGM11);
	TCCR1B |= (1 << WGM12);
	TCCR1B |= (1 << WGM13);

	// set the prescaler. Clk/8
	TCCR1B |= (1 << CS11); // 0.5 us tick

	// TIMSK - enable Output Compare A Match Interrupt
	TIMSK1 |= (1 << OCIE1A);

	// OCR1, Output Compare Register
	OCR1A = 1999; // This is to give an interrupt every 1ms 0 - 1999 = 2000 ticks. 2000ticks * 0.5us = 1ms

	sei(); // Enable all Interrupts
}


uint32_t get_count_t1(){
	uint8_t SREG_old = SREG; //take copy of AVR Status reg
	cli(); //Clear interrupts
	uint16_t local_TCNT1 = TCNT1;
	uint8_t local_TIFR = bitRead(TIFR1,1);

	if(local_TIFR){
		local_TCNT1 = TCNT1;
		T1_overflow_count++;
		TIFR1 |= (1 << OCF1A);
	}
	uint32_t ticks = local_TCNT1 + (T1_overflow_count * 2000); // Returns the number of ticks.
	sei(); // Set interrupts
	SREG = SREG_old;

	return ticks;
}



float get_micros_t1(){
	return get_count_t1() * 0.5;
}


// NOTE: Not very accurate due to checking count and not isr
// Useful for debug
void delay_t1(uint16_t ms){
	// Initial value
	volatile uint32_t start = T1_overflow_count;

	// Do While True
	while (T1_overflow_count < (start+ms)){}
}

/* END OF FILE */
