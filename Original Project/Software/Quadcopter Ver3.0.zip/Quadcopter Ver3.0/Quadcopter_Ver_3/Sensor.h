/*
 * Sensor.h
 *
 *  Created on: 14 Dec 2016
 *      Author: Kevin
 */
#include <arduino.h>

#ifndef SENSOR_H_
#define SENSOR_H_

// Calibration Offsets - These are aquired from running the Calibration program

#define X_GRYRO_OFFSET 89 //Calibrated 28/03/17 KR Office
#define Y_GRYRO_OFFSET 56 //Calibrated 28/03/17 KR Office
#define Z_GRYRO_OFFSET 38 //Calibrated 28/03/17 KR Office

#define X_ACCEL_OFFSET -5193 	//Calibrated 28/03/17 KR Office
#define Y_ACCEL_OFFSET 2336 	//Calibrated 28/03/17 KR Office
#define Z_ACCEL_OFFSET 811 		//Calibrated 28/03/17 KR Office

/*
#define X_GRYRO_OFFSET 96 //Calibrated 30/12/16 KR Office
#define Y_GRYRO_OFFSET 46 //Calibrated 30/12/16 KR Office
#define Z_GRYRO_OFFSET 41 //Calibrated 30/12/16 KR Office

#define X_ACCEL_OFFSET -5219 	//Calibrated 30/12/16 KR Office
#define Y_ACCEL_OFFSET 2354 	//Calibrated 30/12/16 KR Office
#define Z_ACCEL_OFFSET 899 		//Calibrated 30/12/16 KR Office
*/
#define SENSOR_DEBUG 1 // 1 = Active, 0 = Deactive


//#define INTERRUPT_PIN 3  // use pin 2 on Arduino Uno & most boards
#define MPU_INT_PIN 12 //A0

//Global variables - Definition
extern float angleYPR[3];           // [yaw, pitch, roll]   yaw/pitch/roll container and gravity vector
extern int16_t gyroYPR[3];

extern volatile bool mpuInterrupt;

// Public Functions
void init_sensor();
void get_sensor();

//Private Functions
void mpuISR();


#endif /* SENSOR_H_ */
