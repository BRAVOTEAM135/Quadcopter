/*
 * LEDs.h
 *
 *  Created on: 21 Dec 2016
 *      Author: Kevin
 */
#include "Arduino.h"
#ifndef LEDS_H_
#define LEDS_H_

#define LED_PIN 13 //Blue LED
#define ENABLE 1

// Analog Pins used as GPIO
#define GPIO0 A0
#define GPIO1 A1
#define GPIO2 A2
#define GPIO3 A3

void init_a_leds(); // Initialise analog leds
void init_d_leds(); // Initialise digital leds

void set_led(uint8_t pin); // Sets LED pin HIGH
void clear_led(uint8_t pin); // Set LED pin LOW
void toggle_led(uint8_t pin); // Toggle LED Pin


#endif /* LEDS_H_ */
