/*
 * Source File Rules:
 * ------------------
 * - Constants MUST be defined with capitals. E.g #define VALUE 10
 * - Functions MUST follow the following standard. E.g. adc_init(), adc_write()
 * - Variables Must follow the following standard. E.g. adcValueX, adcValueY
 * - Call by reference for variables. E.g.
 *
 * int a = 100;
 * int b = 200;
 * 
 * swap(&a, &b); //pass variable address in
 * 
 * Where
 * void swap(int *x, int *y){ // using the address will point to value (*x)
 * 	int temp;
 * 	temp = *x;
 * 	*x = *y;
 * 	*y = temp;
 * }
 * }
 * 
 * Source File Comments:
 * ---------------------
 *
 *
 *
 */

/*----- #include -----*/
 #include "Arduino.h" /* Required to use the arduino libary */
 #include "PID.h"
 #include "T1.h"

/*----- Constants (#define) -----*/


/*----- (Module) Local Variables (Static) -----*/

/*----- Local Function -----*/


/*----- Global Functions -----*/
// Ensure the timer is initialized as this is need for D and I
void init_pid(){
	init_t1();
	}

// Constructor, function called as soon at the object is created
// All variables are initialized by the constructor to 0
// All variables are also private to the class
PID::PID(){
	PID::error = 0;
	PID::previousTimeI = 0;
	PID::sumError = 0;
	PID::previousTimeD = 0;
	PID::previousErrorD = 0;
	PID::currentTime = 0;
	PID::dt = 0;
	PID::d = 0;

}

// Proportional Function
float PID::p_pid(float setPoint, float processVariable) {
		PID::error = setPoint - processVariable;
		return PID::error;
	}

// Integral Function
float PID::i_pid(float setPoint, float processVariable) {
	PID::error = setPoint - processVariable;
	PID::currentTime = get_micros_t1();
	PID::dt = PID::currentTime - PID::previousTimeI;
	PID::sumError =+ (PID::error / PID::dt);
	PID::previousTimeI = PID::currentTime;
	return PID::sumError;
}

// Derivative Function
float PID::d_pid(float setPoint, float processVariable){
	PID::error = setPoint - processVariable;
	PID::currentTime = get_micros_t1();
	PID::dt = PID::currentTime - PID::previousTimeD;
	PID::d = (PID::previousErrorD - PID::error)/PID::dt;
	PID::previousErrorD = PID::error;
	PID::previousTimeD = PID::currentTime;
	return PID::d;
}


/* END OF FILE */
