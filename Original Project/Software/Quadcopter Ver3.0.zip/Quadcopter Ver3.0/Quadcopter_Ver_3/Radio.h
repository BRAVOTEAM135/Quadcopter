/*
 * Radio.h
 *
 *  Created on: 12 Feb 2017
 *      Author: Kevin
 */

#ifndef RADIO_H_
#define RADIO_H_
#include <Arduino.h>

class Radio {

public:
	Radio(); //Constructor
	void init_channels();


	// Functions that handle the read of the channels. Raw Values
	uint16_t read_raw_THRO();	// PCINT18	PIN2	PD2
	uint16_t read_raw_ALIE();	// PCINT20	PIN4	PD4
	uint16_t read_raw_ELEV();	// PCINT23	PIN7	PD7
	uint16_t read_raw_RUDD();	// PCINT0	PIN8	PB0
	uint16_t read_raw_GEAR();	// PCINT1	PIN9	PB1
	uint16_t read_raw_AUX1();	// PCINT2	PIN10	PB2

	//Scaled values
	float THRO(); // 0 - 100
	float ALIE(); // -100 - 100
	float ELEV(); // -100 - 100
	float RUDD(); //-100 - 100
	uint8_t GEAR(); // 0 to 1
	uint8_t AUX1(); // 0 to 1
	uint8_t TH_CUT();




private:

	// Holds the previous measured value
	volatile uint16_t last_channel_value_THRO; // THRO
	volatile uint16_t last_channel_value_ALIE; // ALIE
	volatile uint16_t last_channel_value_ELEV; // ELEV
	volatile uint16_t last_channel_value_RUDD; // RUDD
	volatile uint16_t last_channel_value_GEAR; // GEAR
	volatile uint16_t last_channel_value_AUX1; // AUX1


	// Stores the rise time
	volatile uint16_t rise_time_THRO; // THRO
	volatile uint16_t rise_time_ALIE; // ALIE
	volatile uint16_t rise_time_ELEV; // ELEV
	volatile uint16_t rise_time_RUDD; // RUDD
	volatile uint16_t rise_time_GEAR; // GEAR
	volatile uint16_t rise_time_AUX1; // AUX1

	// Stores the fall time
	volatile uint16_t fall_time_THRO; // THRO
	volatile uint16_t fall_time_ALIE; // ALIE
	volatile uint16_t fall_time_ELEV; // ELEV
	volatile uint16_t fall_time_RUDD; // RUDD
	volatile uint16_t fall_time_GEAR; // GEAR
	volatile uint16_t fall_time_AUX1; // AUX1

	//Stores the measured pulse width
	volatile uint16_t THRO_pulse_width;
	volatile uint16_t ALIE_pulse_width;
	volatile uint16_t ELEV_pulse_width;
	volatile uint16_t RUDD_pulse_width;
	volatile uint16_t GEAR_pulse_width;
	volatile uint16_t AUX1_pulse_width;






};

#endif /* RADIO_H_ */
