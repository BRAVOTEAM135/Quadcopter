/*
 * Analog_Read.cpp
 *
 *  Created on: 28 Dec 2016
 *      Author: Kevin
 *      Descriotion: Analog Read library handles reading from a single anlog channel performing some smoothing to filter out
 *      noise from the signal to ensure a relatively smooth signal.
 */
#include "Analog_Read.h"

const int numReadings = 35;	// Number of values to uses in the smoothing algorithm

int readings[numReadings];      // the readings from the analog input
int readIndex = 0;              // the index of the current reading
int total = 0;                  // the running total
float average = 0;                // the average

// Initialise the Analog Read hardware ADC ready for reading
void init_analog_read(){
	 // ----- ADMUX -----
	  // ADC Multiplexer Selection Register
	  // 7    6   5   4   3   2   1   0
	  // REFS1  REFS0 ADLAR -   MUX3  MUX2  MUX1  MUX0

	  //0   1   0       1   0   0   0

	  //ADMUX: ADC Multiplexer Selection Register
	  // clear ADLAR in ADMUX (0x7C) to right-adjust the result
	  // ADCL will contain lower 8 bits, ADCH upper 2 (in last two bits)
	  ADMUX &= B11011111;

	  // Set REFS1..0 in ADMUX (0x7C) to change reference voltage to the
	  // proper source (01)
	  ADMUX |= B01000000;

	  // Clear MUX3..0 in ADMUX (0x7C) in preparation for setting the analog
	  // input
	  ADMUX &= B11110000;

	  // Set MUX3..0 in ADMUX (0x7C) to read from AD8 (Internal temp)
	  // Do not set above 15! You will overrun other parts of ADMUX. A full
	  // list of possible inputs is available in Table 24-4 of the ATMega328
	  // datasheet
	  // ADMUX |= 8;
	  // ADMUX |= B00001000; // Binary equivalent
	  ADMUX |= B00000011;


	  // ----- ADCSRA -----
	  // ADC Control and Status Register A
	  // 7    6   5   4   3   2   1   0
	  // ADEN ADSC  ADATE ADIF  ADIE  ADPS2 ADPS1 ADPS0
	  // 1    1   1   0   1   1   1   1

	  // Set ADEN in ADCSRA (0x7A) to enable the ADC. (ADC Enable)
	  // Note, this instruction takes 12 ADC clocks to execute
	  ADCSRA |= B10000000;

	  // Set ADATE in ADCSRA (0x7A) to enable auto-triggering. (ADC Auto Trigger Enable)
	  ADCSRA |= B00100000;

	  // Set the Prescaler to 128 (16000KHz/128 = 125KHz)
	  // Above 200KHz 10-bit results are not reliable.
	  ADCSRA |= B00000111;

	  // Set ADIE in ADCSRA (0x7A) to enable the ADC interrupt.
	  // Without this, the internal interrupt will not trigger.
	  ADCSRA |= B00001000;



	  // ----- ADCSRB -----
	  // ADC Control and Status Register B
	  // 7    6   5   4   3   2   1   0
	  // -    ACME  -   -   -   ADTS2 ADTS1 ADPT0
	  // 0    0   0   0   0   0   0   0
	  // Clear ADTS2..0 in ADCSRB (0x7B) to set trigger mode to free running.
	  // This means that as soon as an ADC has finished, the next will be
	  // immediately started.
	  ADCSRB &= B11111000;

	  // Enable global interrupts
	  // AVR macro included in <avr/interrupts.h>, which the Arduino IDE
	  // supplies by default.
	  sei();

	  // Kick off the first ADC
	  readFlag = 0;
	  // Set ADSC in ADCSRA (0x7A) to start the ADC conversion
	  ADCSRA |=B01000000;
}

// Smoothing function to filter out noise.
float smoothing(){
	// Smoothing - take 20us to execute
	// Check to see if the value has been updated
	  if (readFlag == 1){
	    // Perform whatever updating needed
	  // subtract the last reading:
	  total = total - readings[readIndex];
	  // read from the sensor:
	  readings[readIndex] = analogVal;
	  // add the reading to the total:
	  total = total + readings[readIndex];
	  // advance to the next position in the array:
	  readIndex = readIndex + 1;

	  // if we're at the end of the array...
	  if (readIndex >= numReadings) {
	    // ...wrap around to the beginning:
	    readIndex = 0;
	  }
	  // calculate the average:
	  average = total / numReadings;

	  readFlag = 0;
	  }

	  if(average > 0){
	  return average;
	  }
	  else
		  return 0;

}

// Interrupt service routine for the ADC completion
ISR(ADC_vect){

  // Done reading
  readFlag = 1;

  // Must read low first
  analogVal = ADCL | (ADCH << 8);

  // Not needed because free-running mode is enabled.
  // Set ADSC in ADCSRA (0x7A) to start another ADC conversion
  // ADCSRA |= B01000000;
}

