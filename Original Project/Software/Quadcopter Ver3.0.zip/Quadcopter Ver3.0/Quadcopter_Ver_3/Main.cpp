/*
 * COMMENTS
 * LED_PIN - used as status pin heart beat of the system
 * GPIO0 - Used to show if in program mode for calibration on init / for debug
 * GPIO1 - Throttle Cut off Switch
 * GPIO2 - AUX1 used to enter motor calibration
 * GPIO3 - Gear/ AI - For AI jumper must be removed
 *
 * Motors
 * M1 Pin 3
 * M2 Pin 5
 * M3 Pin 6
 * M4 Pin 11
 *
 *    (M1)      (M2)
 * 		 \      /
 * 		  \____/        ^
 * 	 	  |    |        |
 * 	 	  |____|        |  FORWARD
 *   	 /      \
 * 	    /        \
 *	  (M3)      (M4)
 *
 *	M1 = Yellow
 *	M2 = Red
 *	M3 = Green
 *	M4 = Blue
 *
 *
 * While tuning the header must be off and the TUNE must be set to 1, in LED.h ENABLE must be 0
 * */

#include <Arduino.h>
#include "Sensor.h" // this a libaray I wrote that wraps up the mpu6050 code. A little crude but its wrapped
#include "Radio.h"
#include "Motors.h"
#include "T1.h"
#include "Watchdog.h"
#include "Mixer.h"
#include "PID.h"
#include "LEDs.h"
#include "Analog_Read.h"

// ===== CONFIG/SETTINGS ====
#define MAIN_DEBUG  	//Comment out to remvoe debugging
#define TUNE 1 			// Set to 1 if tunning 0 if not tunning. Note: Tunning will disable GPIO1-3.
						// also jumper off for tuning jumper on for normal operation


// #define SENSOR_DEBUG_PRINT // Uncomment what is needed. This is purley for debug
 //#define RADIO_DEBUG_PRINT
 #define GAIN_DEBUG_PRINT
// #define MOTORS_DEBUG_PRINT


//===== TASKS =====
// Configure all the task counts and initialize them to 0
// See initT1() - currently count will increment every 1ms
volatile unsigned long task_0_count = 0; // Heart beat Task on pin 13
volatile unsigned long task_1_count = 0; // Serial Task
volatile unsigned long task_2_count = 0; // Main Control loop Task
volatile unsigned long task_3_count = 0; // GPIO Task
volatile unsigned long task_3a_count = 0; // Blink LED Task
volatile unsigned long task_4_count = 0; // Safety Task
volatile unsigned long task_5_count = 0; // Sensor Settling time

bool Error = 0;

// ===== RADIO =====
static float local_thro_demand;
static float local_roll_demand;
static float local_pitch_demand;
static float local_yaw_demand;
static bool local_aux1_demand;
static bool local_gear_demand;

volatile static uint8_t cut_off_flag = 0;

// ===== Radio =====
// Initialise the Radio as an object called TX short for transmitter
Radio TX;
#define PITCH_RADIO_SF 30	// dps
#define ROLL_RADIO_SF 30	// dps
#define YAW_RADIO_SF 150	// dps

// ===== SENSOR =====
// Returns the angle in degrees (degs)
float IMU_yaw_angle;
float IMU_roll_angle;
float IMU_pitch_angle;

// Return the rotational rate in degrees per second (degs/sec)
float gyro_yaw_rate;
float gyro_roll_rate;
float gyro_pitch_rate;

// ===== Analog Input =====
// High when a value is ready to be read
volatile int readFlag;

// Value to store analog result
volatile int analogVal;

float gain = 0; //value used to tune the PID

// ===== PID =====
// Initialise class for each PID loop so that they are unique entities
// These are the 6 PID Loops required
PID RateRoll;
PID RatePitch;
PID RateYaw;

PID PosRoll;
PID PosPitch;
PID PosYaw;

// ----- PID Gains -----
// NOTE: Rate input +/-1000dps
// These will be defines/const once the default gain values are know
float ROLL_RATE_Kp = 0;//0.030;
float ROLL_RATE_Ki = 0;//0.075;
float ROLL_RATE_Kd = 0;//0.008;

float PITCH_RATE_Kp = 0;//0.036;
float PITCH_RATE_Ki = 0;//0.075;
float PITCH_RATE_Kd = 0;//0.008; //0.028;

float YAW_RATE_Kp = 0; //From YT video this should be 4
float YAW_RATE_Ki = 0; // From YT video this shoulld be 0.02
float YAW_RATE_Kd = 0; // nothing here as enough drag from motors


float ROLL_POS_Kp = 0;
float ROLL_POS_Ki = 0;
float ROLL_POS_Kd = 0;

float PITCH_POS_Kp = 0;
float PITCH_POS_Ki = 0;
float PITCH_POS_Kd = 0;

float YAW_POS_Kp = 0;
float YAW_POS_Ki = 0;
float YAW_POS_Kd = 0;

// PID Variables - These are the outputs from the PID calculations
float P_Roll_Rate;
float I_Roll_Rate;
float D_Roll_Rate;
float PID_Roll_Rate;

// Pitch
float P_Pitch_Rate;
float I_Pitch_Rate;
float D_Pitch_Rate;
float PID_Pitch_Rate;

// Yaw
float P_Yaw_Rate;
float I_Yaw_Rate;
float D_Yaw_Rate;
float PID_Yaw_Rate;


//Position - Stab
// Roll
float P_Roll_Pos;
float I_Roll_Pos;
float D_Roll_Pos;
float PID_Roll_Pos;

// Pitch
float P_Pitch_Pos;
float I_Pitch_Pos;
float D_Pitch_Pos;
float PID_Pitch_Pos;

// Yaw
float P_Yaw_Pos;
float I_Yaw_Pos;
float D_Yaw_Pos;
float PID_Yaw_Pos;


// ==== Motor =====
float M1_Val = 1000; // Motor inputs are scaled to match the 1000-2000us from the radio.
float M2_Val = 1000;
float M3_Val = 1000;
float M4_Val = 1000;



/* =========================
 * ===== ARDUINO SETUP =====
 * =========================
 * */

void setup() {
	noInterrupts(); // Disable interrupts while in setup
	Serial.begin(115200); //Initialize Serial comms for debug
	Serial.println("-----*-----");

	//----- Initialize Hardware ----
	// Sensor -----
#ifdef MAIN_DEBUG
	Serial.print("Initialising Sensor...");
#endif

	init_sensor();

#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif

	//Radio -----
#ifdef MAIN_DEBUG
	Serial.print("Initialising Radio...");
#endif

	TX.init_channels();

#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif

	// Motors -----
#ifdef MAIN_DEBUG
	Serial.print("Initialising Motors...");
#endif

	init_motors();
	config_motors();

#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif

	// Timer -----
#ifdef MAIN_DEBUG
	Serial.print("Initialising Timer 1...");
#endif

	init_t1();

#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif

	// Mixer -----
#ifdef MAIN_DEBUG
	Serial.print("Initialising Mixer...");
#endif

	config_mixer(CROSS);

#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif

	// LEDs -----
#ifdef MAIN_DEBUG
	Serial.print("Initialising LEDs...");
#endif

	if(TUNE == 0) init_a_leds(); //If we are tunning disable Analog Pins as Output
	init_d_leds();

#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif
	if(TUNE == 1){

	// Analog Read ------
#ifdef MAIN_DEBUG
		Serial.print("Initialising Analog Read...");
#endif

		init_analog_read();

#ifdef MAIN_DEBUG
		Serial.println("OK");
#endif
	}


	//interrupts(); // Enable interrupts once setup complete
	}



// ================================================================
// ===                    MAIN PROGRAM LOOP                     ===
// ================================================================

void loop() {

	// ===== INITIALIZATION =====
	//Initialize the watchdog. Will only happen once
#ifdef MAIN_DEBUG
	Serial.print("Initialising Watchdog...");
#endif
	init_watchdog();
	reset_watchdog();
#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif

	// clear all LEDs
	clear_led(GPIO0);
	clear_led(GPIO1);
	clear_led(GPIO2);
	clear_led(GPIO3);

	clear_led(LED_PIN);


	reset_watchdog(); // Reset the watchdog

// ===== Motor Calibration =====
/*
	 * To Calibrate
	 * 1. Connect USB cable
	 * 2. Ensure Transmiter and and Rx are connected
	 * 3. Set throttle stick to max
	 * 4. Toggle AUX to ON
	 * 5. Restart the Arduino
	 * 6. Connect the battery
	 * 7. and go through the motor beep sequecne to calibrate
 */
	if(TX.AUX1() == true){
		set_led(GPIO0);
		set_led(GPIO2);

		while(TX.AUX1() == true){

			write_motor_1(TX.THRO());
			write_motor_2(TX.THRO());
			write_motor_3(TX.THRO());
			write_motor_4(TX.THRO());

			reset_watchdog(); // Reset the watchdog
		}

	}
	clear_led(GPIO0);
	clear_led(GPIO2);

	// ===== SENSOR STABLISATION =====
	// Gives the sensors a chance to stablize. Take 10s to do this
#ifdef MAIN_DEBUG
	Serial.print("Initialising IMU takes 12s...");
#endif

	set_led(GPIO0);
	set_led(GPIO1);

	// Show on the LEDs a count down to show system doing something
	while (task_5_count <= 12000) {
		get_sensor();
		reset_watchdog(); // Reset the watchdog
		if(task_5_count < 3000){
			set_led(GPIO0);
			set_led(GPIO1);
			set_led(GPIO2);
			set_led(GPIO3);
			set_led(LED_PIN);
		}
		else if (task_5_count >= 3000 & task_5_count < 6000 ){
			clear_led(GPIO0);
			set_led(GPIO1);
			set_led(GPIO2);
			set_led(GPIO3);
			set_led(LED_PIN);
		}
		else if (task_5_count >= 6000 & task_5_count < 9000){
			clear_led(GPIO0);
			clear_led(GPIO1);
			set_led(GPIO2);
			set_led(GPIO3);
			set_led(LED_PIN);
		}
		else if (task_5_count >= 9000 & task_5_count < 12000){
			clear_led(GPIO0);
			clear_led(GPIO1);
			clear_led(GPIO2);
			set_led(GPIO3);
			set_led(LED_PIN);
		}
	}
	clear_led(GPIO0);
	clear_led(GPIO1);
	clear_led(GPIO2);
	clear_led(GPIO3);
	clear_led(LED_PIN);
#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif
	// ===== THROTTLE SAFETY =====
	// Safety: Ensure software does not start until the motors are in a safe position
	static uint8_t init_thro = 1; // Local to serve as the first reading from the radio

#ifdef MAIN_DEBUG
	Serial.println("Throttle Safety...");
#endif

	while(init_thro > 1000){
		set_led(LED_PIN); // Light LED to show nothing happening

		init_thro = TX.THRO(); // Store read value locally

#ifdef MAIN_DEBUG
		Serial.println(init_thro);
#endif

		reset_watchdog(); // Reset the watchdog
	}

#ifdef MAIN_DEBUG
	Serial.println("OK");
#endif

	// clear all LEDs
	clear_led(GPIO3);
	clear_led(GPIO2);
	clear_led(GPIO1);

	clear_led(LED_PIN); //All good to start running program turn led off

	// =====================
	// ===== MAIN LOOP =====
	// =====================
	//Create an infinite loop - enables for "void loop" initialization
	while(1) {

		// ---------------------
		// ----- Heartbeat -----
		// ---------------------
		// Called every 500ms and toggles the LED pin to show the system is alive and running
		if (task_0_count >= 500){
			task_0_count = 0;

			if (Error) set_led(LED_PIN); // If there is an error set the LED PIN constant on
			else toggle_led(LED_PIN); // Else flash the LED
		}

		// ------------------
		// ----- Serial -----
		// ------------------
		// Every 100ms this function is called 10Hz
		if (task_1_count >= 100) {
			task_1_count = 0; // Reset Task Counter



			// ----- Sensor Debug -----
#ifdef SENSOR_DEBUG_PRINT
			// ANGLE
			Serial.print("y-agl: ");
			//Serial.print(angleYPR[0]); // Yaw Global Variable
			Serial.print(IMU_yaw_angle,2); // Yaw
			Serial.print("\t");

			Serial.print("r-agl: ");
			//Serial.print(angleYPR[1]); // Roll Global Variable
			Serial.print(IMU_roll_angle,2); // Roll
			Serial.print("\t");

			Serial.print("p-agl: ");
			//Serial.print(angleYPR[2]); // Pitch Global Variable
			Serial.print(IMU_pitch_angle,2);
			Serial.print("\t");

			// RATE
			Serial.print("y_rte: ");
			//Serial.print(gyroYPR[2]); //Yaw Global Variable
			Serial.print(gyro_yaw_rate,2);
			Serial.print("\t");

			Serial.print("r_rte: ");
			//Serial.print(gyroYPR[1]); // Roll Global Variable
			Serial.print(gyro_roll_rate,2);
			Serial.print("\t");

			Serial.print("p_rte: ");
			//Serial.print(gyroYPR[0]); // Pitch Global Variable
			Serial.print(gyro_pitch_rate,2);

			Serial.println();
#endif

#ifdef RADIO_DEBUG_PRINT
			// ----- Radio Debug -----
/*
			Serial.print(TX.THRO());
			Serial.print("\t");
			Serial.print(TX.ALIE());
			Serial.print("\t");
			Serial.print(TX.ELEV());
			Serial.print("\t");
			Serial.print(TX.RUDD());
			Serial.print("\t");
			Serial.print(TX.GEAR());
			Serial.print("\t");
			Serial.print(TX.AUX1());
			Serial.print("\t");
			Serial.print(TX.TH_CUT());
			Serial.println();
*/
			Serial.print(local_thro_demand);
			Serial.print("\t");
			Serial.print(local_roll_demand);
			Serial.print("\t");
			Serial.print(local_pitch_demand);
			Serial.print("\t");
			Serial.print(local_yaw_demand);
			Serial.print("\t");
			Serial.print(TX.GEAR());
			Serial.print("\t");
			Serial.print(TX.AUX1());
			Serial.print("\t");
			Serial.print(TX.TH_CUT());
			Serial.println();
#endif

			// ----- Gain Debug -----
#ifdef GAIN_DEBUG_PRINT
			Serial.print(gain,3);
			Serial.println();
#endif

			// ----- Motors Debug -----
#ifdef MOTORS_DEBUG_PRINT
			Serial.print(M1_Val);
			Serial.print("\t");
			Serial.print(M2_Val);
			Serial.print("\t");
			Serial.print(M3_Val);
			Serial.print("\t");
			Serial.print(M4_Val);
			Serial.println();
#endif
		}

		//------------------------------
		// ----- Main Control Loop -----
		// -----------------------------
		// Called every 5ms. 200Hz
		else if(task_2_count >= 5) {
			task_2_count = 0; // Reset the task counter

			// ----- SENSOR -----
			get_sensor();
			// Assign to global variable to local variable to ensure using same instance of data.
			IMU_yaw_angle = angleYPR[0];	// Units: Degrees
			IMU_roll_angle = angleYPR[1];
			IMU_pitch_angle = angleYPR[2];

			gyro_yaw_rate = gyroYPR[0];	// Units: dps (Degrees per Second)
			gyro_roll_rate = gyroYPR[1];
			gyro_pitch_rate = gyroYPR[2];


			// ----- RADIO -----
			// Take a local copy of the latest value read from Radio
			local_thro_demand = TX.THRO();	// Min = 1071, Max = 1943 - Units: us
			local_roll_demand = TX.ALIE() * ROLL_RADIO_SF; 	// Raw: Left = -1, Right = 1
			local_pitch_demand = TX.ELEV() * PITCH_RADIO_SF;	// Raw: Up/Forward = 1, Down/Backward = -1
			local_yaw_demand = TX.RUDD() * YAW_RADIO_SF;	// Raw: Left = -1, Right = 1
			local_aux1_demand = TX.AUX1();	// Off = 0, On = 1
			local_gear_demand = TX.GEAR();	// Off = 0, On = 1

			// Light LED if AUX Toggled
			if (local_aux1_demand){
				set_led(GPIO2);
			}
			else {
				clear_led(GPIO2);
			}

			// Light LED if Gear Demand Toggled
			if (local_gear_demand){
				set_led(GPIO1);
			}
			else {
				clear_led(GPIO1);
			}



			 // ----- TUNNING -----
#ifdef TUNE
			PITCH_RATE_Kp = gain;
#endif

			//----- PID -----
			// -----------------------
			// ----- Rate : Acro -----
			// -----------------------
			// Roll ----
			P_Roll_Rate = RateRoll.p_pid(local_roll_demand, gyro_roll_rate); // local_roll_demand - From the Sticks see ROLL_RADIO_SF +/-30 dps
			I_Roll_Rate = RateRoll.i_pid(local_roll_demand, gyro_roll_rate); // gyro_roll_rate - this is from the imu dps
			D_Roll_Rate = RateRoll.d_pid(local_roll_demand, gyro_roll_rate);

			PID_Roll_Rate = (P_Roll_Rate * ROLL_RATE_Kp) + (I_Roll_Rate * ROLL_RATE_Ki) + (D_Roll_Rate * ROLL_RATE_Kd);

			// Pitch ----
			P_Pitch_Rate = RatePitch.p_pid(local_pitch_demand, gyro_pitch_rate);
			I_Pitch_Rate = RatePitch.i_pid(local_pitch_demand, gyro_pitch_rate);
			D_Pitch_Rate = RatePitch.d_pid(local_pitch_demand, gyro_pitch_rate);

			PID_Pitch_Rate = (P_Pitch_Rate * PITCH_RATE_Kp) + (I_Pitch_Rate * PITCH_RATE_Ki) + (D_Pitch_Rate * PITCH_RATE_Kd);

			// Yaw -----
			P_Yaw_Rate = RateYaw.p_pid(0.000, gyro_yaw_rate);
			I_Yaw_Rate = RateYaw.i_pid(0.000, gyro_yaw_rate);
			D_Yaw_Rate = RateYaw.d_pid(0.000, gyro_yaw_rate);

			PID_Yaw_Rate = (P_Yaw_Rate * YAW_RATE_Kp) + (I_Yaw_Rate * YAW_RATE_Ki) + (D_Yaw_Rate * YAW_RATE_Kd);


			//----- Position : Stab -----
			// Roll
			P_Roll_Pos = PosRoll.p_pid(0,0);
			I_Roll_Pos = PosRoll.i_pid(0,0);
			D_Roll_Pos = PosRoll.d_pid(0,0);

			PID_Roll_Pos = (P_Roll_Pos * ROLL_POS_Kp) + (I_Roll_Pos * ROLL_POS_Ki) + (D_Roll_Pos * ROLL_POS_Kd);

			// Pitch
			P_Pitch_Pos = PosPitch.p_pid(0,0);
			I_Pitch_Pos = PosPitch.i_pid(0,0);
			D_Pitch_Pos = PosPitch.d_pid(0,0);

			PID_Pitch_Pos = (P_Pitch_Pos * PITCH_POS_Kp) + (I_Pitch_Pos * PITCH_POS_Ki) + (D_Pitch_Pos * PITCH_POS_Kd);

			// Yaw
			P_Yaw_Pos = PosYaw.p_pid(0,0);
			I_Yaw_Pos = PosYaw.i_pid(0,0);
			D_Yaw_Pos = PosYaw.d_pid(0,0);
			PID_Yaw_Pos = (P_Yaw_Pos * YAW_POS_Kp) + (I_Yaw_Pos * YAW_POS_Ki) + (D_Yaw_Pos * YAW_POS_Kd);


			// ----- MIXER -----
			// If Thro demand above a sensible threshold begin control
			if(local_thro_demand > 1150){
				// ----- Motor Mix -----
				//Note: this is for X configuration motor mix

				write_motor_1(local_thro_demand + PID_Pitch_Rate + PID_Roll_Rate - PID_Yaw_Rate); // Yellow
				M1_Val = local_thro_demand + PID_Pitch_Rate + PID_Roll_Rate - PID_Yaw_Rate;

				write_motor_2(local_thro_demand + PID_Pitch_Rate - PID_Roll_Rate + PID_Yaw_Rate); // RED
				M2_Val = local_thro_demand + PID_Pitch_Rate - PID_Roll_Rate + PID_Yaw_Rate;

				write_motor_3(local_thro_demand - PID_Pitch_Rate + PID_Roll_Rate + PID_Yaw_Rate); // Green
				M3_Val = local_thro_demand - PID_Pitch_Rate + PID_Roll_Rate + PID_Yaw_Rate;

				write_motor_4(local_thro_demand - PID_Pitch_Rate - PID_Roll_Rate - PID_Yaw_Rate); // Blue
				M4_Val = local_thro_demand - PID_Pitch_Rate - PID_Roll_Rate - PID_Yaw_Rate;

			}
			else	//Below the throttle Threshold command all motors to the same speed.
					write_motor_1(local_thro_demand);
					M1_Val = local_thro_demand;

					write_motor_2(local_thro_demand);
					M2_Val = local_thro_demand;

					write_motor_3(local_thro_demand);
					M3_Val = local_thro_demand;

					write_motor_4(local_thro_demand);
					M4_Val = local_thro_demand;
		}


		// ---------------------
		// ----- GPIO Task -----
		// ---------------------
		else if(task_3_count >= 10) {
			task_3_count = 0; // Reset the task counter
			task_3a_count++;

			// Causes LED to Blink - From HERE
			// Sub-task at different rate to parent task.
			if(task_3a_count == 10) {
				//ON LED
				 set_led(GPIO0);
			}
			else if(task_3a_count == 20){
				//OFF LED
				 clear_led(GPIO0);
			}
			else if(task_3a_count == 30){
				//ON LED
				 set_led(GPIO0);
			}
			else if(task_3a_count == 40){
				//OFF LED
				 clear_led(GPIO0);
			}
			else if(task_3a_count == 100){
				task_3a_count = 0;
			}
			// To HERE

		}


		// -----------------------
		// ----- SAFETY Task -----
		// -----------------------
		// Task always running as this is a safety loop to kill the motors quick
		if (task_4_count == 5){
			task_4_count = 0;
			if(TX.TH_CUT() == true) {

				set_led(GPIO3);

				write_motor_1(1000);
				write_motor_2(1000);
				write_motor_3(1000);
				write_motor_4(1000);

				cut_off_flag = 1; // Raise flag to say cut off occured
			}

			// No Throttle cut off - proceed as normal
			else {
				//Ensure that after cut off the throttle needs to return to 0 before starting again
				if (cut_off_flag == 1) { //has cut off occured
					if (local_thro_demand <= 1075) { // has throttle zeroed
						cut_off_flag = 0;
					}
					// Throttle in an unsafe position
					else {
						set_led(GPIO3);
					}
				}
			}
		}

		// --------------------------------------------
		// ----- Things to Do on Every loop cycle -----
		// --------------------------------------------
		// Reset the watch dog timer. Needs a reset every 15ms
		reset_watchdog();

		// ----- GAIN TUNING -----
		// Get the gain value and scale for desired range
		// Out of the smoothing function we see 0 - 900

		// Gain Range 0.000 -> 0.001
		//gain = smoothing() / 900000;

		// Gain Range 0.000 - > 0.01
		//gain = smoothing() / 90000;

		// Gain Range 0.000 -> 0.100
		//gain = smoothing() / 9000;

		// Gain Range 0.000 -> 1.000
		//gain = smoothing() / 900;

		// Gain Range 0.000 -> 0.250
		gain = smoothing() / 3600;

		// Gain Range 0.000 -> 0.500
		 //gain = smoothing() / 1800;



	}
}


// --------------------------------------
// ----- Interrupt Service Routines -----
// --------------------------------------
ISR(PCINT0_vect){

	//Radio Signals
	TX.read_raw_RUDD();	// PCINT0	PIN8	PB0
	TX.read_raw_GEAR();	// PCINT1	PIN9	PB1
	TX.read_raw_AUX1();	// PCINT2	PIN10	PB2

	// For the Sensor
	mpuInterrupt = true;
}

// PCINT[14:8]
ISR(PCINT1_vect){

}

// PCINT[16:23]
ISR(PCINT2_vect){

	// Radio Signals
	TX.read_raw_THRO();	// PCINT18	PIN2	PD2
	TX.read_raw_ELEV();	// PCINT23	PIN7	PD7
	TX.read_raw_ALIE();	// PCINT20	PIN4	PD4
}
