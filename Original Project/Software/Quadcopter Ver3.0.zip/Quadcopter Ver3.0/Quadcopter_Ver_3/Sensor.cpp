/*
 * Sensor.cpp
 *
 *  Created on: 14 Dec 2016
 *      Author: Kevin
 */
#include "Sensor.h"

#include "I2Cdev.h"
#include "MPU6050_6Axis_MotionApps20.h"

// Arduino Wire library is required if I2Cdev I2CDEV_ARDUINO_WIRE implementation
// is used in I2Cdev.h
#if I2CDEV_IMPLEMENTATION == I2CDEV_ARDUINO_WIRE
    #include "Wire.h"
#endif

// class default I2C address is 0x68
// specific I2C addresses may be passed as a parameter here
// AD0 low = 0x68 (default for SparkFun breakout and InvenSense evaluation board)
// AD0 high = 0x69
MPU6050 mpu;

//bool blinkState = false;

// MPU control/status vars
bool dmpReady = false;  // set true if DMP init was successful
uint8_t mpuIntStatus;   // holds actual interrupt status byte from MPU
uint8_t devStatus;      // return status after each device operation (0 = success, !0 = error)
uint16_t packetSize;    // expected DMP packet size (default is 42 bytes)
uint16_t fifoCount;     // count of all bytes currently in FIFO
uint8_t fifoBuffer[64]; // FIFO storage buffer

// orientation/motion vars
Quaternion q;           // [w, x, y, z]         quaternion container
VectorFloat gravity;    // [x, y, z]            gravity vector
float ypr[3];           // [yaw, pitch, roll]   yaw/pitch/roll container and gravity vector
int16_t gx, gy, gz;		// Gyro Rate variables
float angleYawBuffer = 0;
float angleYawOffset = 0;
bool flag;

// Global variable initialisation
float angleYPR[3];
int16_t gyroYPR[3];

volatile bool mpuInterrupt = false;     // indicates whether MPU interrupt pin has gone high



void init_sensor(){
	// join I2C bus (I2Cdev library doesn't do this automatically)
	#if I2CDEV_IMPLEMENTATION == I2CDEV_ARDUINO_WIRE
	Wire.begin();
	Wire.setClock(400000); // 400kHz I2C clock. Comment this line if having compilation difficulties
	#elif I2CDEV_IMPLEMENTATION == I2CDEV_BUILTIN_FASTWIRE
	Fastwire::setup(400, true);
	#endif

	// initialize device
	if (SENSOR_DEBUG == 1) Serial.println(F("Initializing I2C devices..."));
	mpu.initialize();

	//init_sensor_isr(); //Handles initializing the sensor PCINTs
	PCICR |= (1 << PCIE0);
	PCMSK0 |= (1 << PCINT4);	// MPU INT - Pin12


	// verify connection
	if (SENSOR_DEBUG == 1)Serial.println(F("Testing device connections..."));
	if (SENSOR_DEBUG == 1)Serial.println(mpu.testConnection() ? F("MPU6050 connection successful") : F("MPU6050 connection failed"));

	if (SENSOR_DEBUG == 1) while (Serial.available() && Serial.read()); // empty buffer again

	// load and configure the DMP
	if (SENSOR_DEBUG == 1) Serial.println(F("Initializing DMP..."));
	devStatus = mpu.dmpInitialize(); // This is in the original code - but has no declaration??
    mpu.initialize(); // This is what initializes the registers

	if (SENSOR_DEBUG) Serial.print("Gyro Range: ");
	if (SENSOR_DEBUG) Serial.println(mpu.getFullScaleGyroRange());
	if (SENSOR_DEBUG) Serial.print("Accel Range: ");
	if (SENSOR_DEBUG) Serial.println(mpu.getFullScaleAccelRange());

	// supply your own gyro offsets here, scaled for min sensitivity
	// Run the MPU6050 Calibration program to get these values
	mpu.setXGyroOffset(X_GRYRO_OFFSET); // (Original: 220)
	mpu.setYGyroOffset(Y_GRYRO_OFFSET); //  (Original: 76)
	mpu.setZGyroOffset(Z_GRYRO_OFFSET); // (Original: -85)

	mpu.setXAccelOffset(X_ACCEL_OFFSET);
	mpu.setYAccelOffset(Y_ACCEL_OFFSET);
	mpu.setZAccelOffset(Z_ACCEL_OFFSET); // 1688 factory default for my test chip (Original: 1788)

	// make sure it worked (returns 0 if so)
	if (devStatus == 0) {
		// turn on the DMP, now that it's ready
		if (SENSOR_DEBUG == 1) Serial.println(F("Enabling DMP..."));
		mpu.setDMPEnabled(true);

		if (SENSOR_DEBUG) Serial.print("Gyro Range: ");
		if (SENSOR_DEBUG) Serial.println(mpu.getFullScaleGyroRange());
		if (SENSOR_DEBUG) Serial.print("Accel Range: ");
		if (SENSOR_DEBUG) Serial.println(mpu.getFullScaleAccelRange());


		// enable Arduino interrupt detection
		if (SENSOR_DEBUG == 1) Serial.println(F("Enabling interrupt detection (Arduino PCINT8 A0  )..."));
		//attachInterrupt(digitalPinToInterrupt(INTERRUPT_PIN), dmpDataReady, RISING);

		mpuIntStatus = mpu.getIntStatus();

		// set our DMP Ready flag so the main loop() function knows it's okay to use it
		if (SENSOR_DEBUG == 1) Serial.println(F("DMP ready! Waiting for first interrupt..."));
		dmpReady = true;

		// get expected DMP packet size for later comparison
		packetSize = mpu.dmpGetFIFOPacketSize();
		if (SENSOR_DEBUG == 1) Serial.print(F("FIFO Packet Size: "));
		if (SENSOR_DEBUG == 1) Serial.println(packetSize);
	}
	else {
		// ERROR!
		// 1 = initial memory load failed
		// 2 = DMP configuration updates failed
		// (if it's going to break, usually the code will be 1)
		if (SENSOR_DEBUG == 1){Serial.print(F("DMP Initialization failed (code "));
			Serial.print(devStatus);
			Serial.println(F(")"));
		}
	}

	// Print the Initial fifo count.
	if (SENSOR_DEBUG == 1) Serial.print(F("FIFO Count: "));
	if (SENSOR_DEBUG == 1) Serial.println(fifoCount);

	// configure LED for output - DEBUG
	//pinMode(LED_PIN, OUTPUT);
}

void get_sensor() {
	// if programming failed, don't try to do anything
	if (!dmpReady) {
		return;
	}

	// wait for MPU interrupt or extra packet(s) available
		if ((mpuInterrupt==true) || fifoCount >= packetSize) {
		//---Read MPU Data---
		// reset interrupt flag and get INT_STATUS byte
		mpuInterrupt = false;

		mpuIntStatus = mpu.getIntStatus();

		// get current FIFO count
		fifoCount = mpu.getFIFOCount();

		// check for overflow (this should never happen unless our code is too inefficient)
		if ((mpuIntStatus & 0x10) || fifoCount == 1024) {
			// reset so we can continue cleanly
			mpu.resetFIFO();
			if (SENSOR_DEBUG == 1) Serial.println(F("FIFO overflow!!!!"));
		}

		// otherwise, check for DMP data ready interrupt (this should happen frequently)
		else if (mpuIntStatus & 0x02) {
			// wait for correct available data length, should be a VERY short wait
			while (fifoCount < packetSize) fifoCount = mpu.getFIFOCount();

			// read a packet from FIFO
			mpu.getFIFOBytes(fifoBuffer, packetSize);

			// track FIFO count here in case there is > 1 packet available
			// (this lets us immediately read more without waiting for an interrupt)
			fifoCount -= packetSize;


			mpu.getRotation(&gx, &gy, &gz);
			// Raw Gyro Value, Rate of rotation Deg/Sec or dps or Degrees per second
			gyroYPR[0] = gz / 16.4; // Divide by 16.4 as this is 16bit 65536 / Full Scale (4000) = 16.4 scales to dpss
			gyroYPR[1] = gy / 16.4;
			gyroYPR[2] = gx / 16.4;

			// display Euler angles in degrees
			//Get MPU Values
			mpu.dmpGetQuaternion(&q, fifoBuffer);
			mpu.dmpGetGravity(&gravity, &q);
			mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);

			// Write values to the global variables for use in the main and other functions
			// Euler Angle
			angleYPR[0] = ypr[0] * 180/M_PI * -1; // * -1 to ensure paradigm matches up with the rate
			angleYPR[1] = ypr[1] * 180/M_PI * -1;
			angleYPR[2] = ypr[2] * 180/M_PI;


/*
 * Code in progress to fix the yaw drift
 *
			// If not moving in Yaw then return the last known yaw angle thats in the buffer
			if (gyroYPR[0] <= 0.009 & gyroYPR[0] >= -0.009){
				if (flag == true){
				angleYawBuffer = angleYPR[0];
				flag = false;
				}
				angleYPR[0] = angleYawBuffer;
				}

			// Else is moving return the yaw
			else {
				angleYawOffset = angleYPR[0] - angleYawBuffer;
				angleYPR[0] = angleYPR[0] + angleYawOffset;
				flag == true;

			}
*/


		}
	}
}


