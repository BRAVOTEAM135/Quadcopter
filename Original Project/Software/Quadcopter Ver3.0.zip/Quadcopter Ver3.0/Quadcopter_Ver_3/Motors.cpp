/*
 * Source File Rules:
 * ------------------
 * - Constants MUST be defined with capitals. E.g #define VALUE 10
 * - Functions MUST follow the following standard. E.g. adc_init(), adc_write()
 * - Variables Must follow the following standard. E.g. adcValueX, adcValueY
 * - Call by reference for variables. E.g.
 *
 * int a = 100;
 * int b = 200;
 * 
 * swap(&a, &b); //pass variable address in
 * 
 * Where
 * void swap(int *x, int *y){ // using the address will point to value (*x)
 * 	int temp;
 * 	temp = *x;
 * 	*x = *y;
 * 	*y = temp;
 * }
 * }
 * 
 * Source File Comments:
 * ---------------------
 * Code showing Phase Correct PWM
 *
 *
 */

/*
 * Timer 0 and 2 are used to generate PWM signals which are then fed to the motors.
 * */
/*----- #include -----*/
 #include "Arduino.h" /* Required to use the arduino libary */
 #include "Motors.h"


/*----- Constants (#define) -----*/


/*
 * _BV same as shifting 1 by the number of places
 * Timer 0 (8 Bit) Pre-scaler values
 * Frequency = System Clock (16MHz) / Pre-scaler / #bits (256 bits)
 */
 
/* Timer 0 (8 bit) Pre-scaler Values */ 
const int T0_PS1		=    _BV(CS00);              // 31.25 khz
const int T0_PS8		=    _BV(CS01);              // 3.90 khz
const int T0_PS64		=    _BV(CS01) | _BV(CS00);  // 488.28 hz
const int T0_PS256		=    _BV(CS02);              // 122.07 hz
const int  T0_PS1024	=    _BV(CS02) | _BV(CS00);  // 30.51 hz

//TImer 2 (8 Bit) Pre-scaler Values
const int  T2_PS1		=   _BV(CS20);
const int  T2_PS8		=   _BV(CS21);
const int  T2_P32		=	_BV(CS21) | _BV(CS20);
const int  T2_PS64		=   _BV(CS22);
const int  T2_PS128		=   _BV(CS22) | _BV(CS20);
const int  T2_PS256		=   _BV(CS22) | _BV(CS21);
const int  T2_PS1024	=   _BV(CS22) | _BV(CS21) | _BV(CS20);


/*----- (Module) Local Variables (Static) -----*/


/*----- Local Function -----*/
// Converts Percentage to Raw 0-255 value that is required
//
/*
 * Obselete as replaced by radio2motor
float perc2raw(int perc) {
	float raw = 0;
	raw = ((perc * 1.03) + 135.00); // Raw min = 135, Raw max = 238;
	//raw = ((perc * 0.65) + 135.00); //raw Min = 135, Max = 200

	return raw;
	}
*/

// input radio will be 1000-2000us which is from the throttle of the radi
float radio2motor(int radio){
	/*
	 *
	 * Motor min = 135, Motor max = 238
	 * 2000 - radio = x
	 * x * (238-135) = y
	 * z = 238 - y
	*/
	float motor = 0;
	motor = 238 - ((2000 - radio)*0.103);
	return motor;
}

/*----- Global Functions -----*/
// Initialise the pin for output and configure the timers for desired output aprox 500hz signal
void init_motors(){
	pinMode(3, OUTPUT);    // OCR2B
	pinMode(11, OUTPUT);   // OCR2A
	pinMode(5, OUTPUT);    // OCR0B
	pinMode(6, OUTPUT);    // OCR0A
	

/* NOTE:
 * COM2A1 = Clear on Match
 * COM2B1 = Clear on match
 * WGM21 and WGM20 = Fast PWM
 * CS22 = prescaler = 64
 * Generate a 490Hz PWM Signal
 */

/*---- TIMER 0 -----
 * TCCR0A - Timer/Counter control register A
 * Bit  |    7     |    6     |    5     |    4     |  3  |  2  |    1    |    0    |
 *      |  COM0A1  |  COM0A0  |  COM0B1  |  COM0B0  |  -  |  -  |  WGM01  |  WGM00  |
 */
	TCCR0A = 0;
	TCCR0A = _BV(COM0A1) | _BV(COM0B1) | _BV(WGM00);
  
/*	 TCCR0B - Timer/Counter control register B
 *	 Bit  |    7     |    6     |    5     |    4     |    3    |    2    |    1   |    0   |
 *	      |  FOC0A   |  FOC0B   |    -     |    -     |  WGM02  |  CS02   |  CS01  |  CS00  |
 */
	TCCR0B = 0;
	TCCR0B = T0_PS64;
	
/*	TIMSK0 - Timer/Counter Interrupt Mask Register 
 *	 Bit  |    7     |    6     |    5     |    4     |    3    |    2    |    1   |    0   |
 *	      |    -  	 |    -  	|    -     |    -     |    0	|OCIE0B   |  OCIE0A|  TOIE0 |  */
  TIMSK0 = 0;
/* ----- TIMER 2 -----
 * TCCR2A - Timer/Counter control register A
 * Bit  |    7     |    6     |    5     |    4     |  3  |  2  |    1    |    0    |
 *      |  COM2A1  |  COM2A0  |  COM2B1  |  COM2B0  |  -  |  -  |  WGM21  |  WGM20  |
 */
	TCCR2A = 0;
	TCCR2A = _BV(COM2A1) | _BV(COM2B1) | _BV(WGM20);
  
/* TCCR2B - Timer/Counter control register B
 * Bit  |    7     |    6     |    5     |    4     |    3    |    2    |    1   |    0   |
 *      |  FOC2A   |  FOC2B   |    -     |    -     |  WGM22  |  CS22   |  CS21  |  CS20  |
 */
	TCCR2B = 0;
	TCCR2B = T2_PS64;
  	}

// Arms the ESC so they are ready to run
void config_motors(){
	/* Arms the ESC 135 is the raw value */
	PWM1 = 125;
	PWM2 = 125;
	PWM3 = 125;
	PWM4 = 125;
	}

// Function to write a percentage value to each motor
void write_motor_1(int M1){
	//PWM1 = M1;
	if(M1 < 1000) M1 = 1000;	// Lower Limit for Motor 0%
	if(M1 > 2000) M1 = 2000;	// Upper Limit for Motor 100%
	PWM1 = radio2motor(M1);
	}
	
void write_motor_2(int M2){
	//PWM2 = M2;
	if(M2 < 1000) M2 = 1000;	// Lower Limit for Motor 0%
	if(M2 > 2000) M2 = 2000;	// Upper Limit for Motor 100%
	PWM2 = (radio2motor(M2));
	}
	
void write_motor_3(int M3){
	//PWM3 = M3;
	if(M3 < 1000) M3 = 1000;	// Lower Limit for Motor 0%
	if(M3 > 2000) M3 = 2000;	// Upper Limit for Motor 100%
	PWM3 = radio2motor(M3);
	}
	
void write_motor_4(int M4){
	//PWM4 = M4;
	if(M4 < 1000) M4 = 1000;	// Lower Limit for Motor 0%
	if(M4 > 2000) M4 = 2000;	// Upper Limit for Motor 100%
	PWM4 = radio2motor(M4);
	}
/* END OF FILE */
