/*
 * New_Radio.cpp
 *
 *  Created on: 12 Feb 2017
 *      Author: Kevin
 */
#include "New_Radio.h"
#include "T1.h"
#include <Arduino.h>

	volatile uint16_t channel_value_THRO; // THRO
	volatile uint16_t channel_value_ALIE; // ALIE
	volatile uint16_t channel_value_ELEV; // ELEV
	volatile uint16_t channel_value_RUDD; // RUDD
	volatile uint16_t channel_value_GEAR; // GEAR
	volatile uint16_t channel_value_AUX1; // AUX1


	volatile uint16_t last_channel_value_THRO; // THRO
	volatile uint16_t last_channel_value_ALIE; // ALIE
	volatile uint16_t last_channel_value_ELEV; // ELEV
	volatile uint16_t last_channel_value_RUDD; // RUDD
	volatile uint16_t last_channel_value_GEAR; // GEAR
	volatile uint16_t last_channel_value_AUX1; // AUX1


	volatile uint16_t rise_time_THRO; // THRO
	volatile uint16_t rise_time_ALIE; // ALIE
	volatile uint16_t rise_time_ELEV; // ELEV
	volatile uint16_t rise_time_RUDD; // RUDD
	volatile uint16_t rise_time_GEAR; // GEAR
	volatile uint16_t rise_time_AUX1; // AUX1

	volatile uint16_t fall_time_THRO; // THRO
	volatile uint16_t fall_time_ALIE; // ALIE
	volatile uint16_t fall_time_ELEV; // ELEV
	volatile uint16_t fall_time_RUDD; // RUDD
	volatile uint16_t fall_time_GEAR; // GEAR
	volatile uint16_t fall_time_AUX1; // AUX1


	volatile uint16_t THRO_pulse_width;
	volatile uint16_t ALIE_pulse_width;
	volatile uint16_t ELEV_pulse_width;
	volatile uint16_t RUDD_pulse_width;
	volatile uint16_t GEAR_pulse_width;
	volatile uint16_t AUX1_pulse_width;



void init_channels(){
	// Clear Interrupts
	cli();

	// Pin Change Interrupt 0 [7:0]
	// Pin Change Interrupt 1 [14:8]
	// Pin Change Interrupt 2 [23:16]
	PCICR |= (1 << PCIE0);
	PCICR |= (0 << PCIE1);
	PCICR |= (1 << PCIE2);

	// Clear all PCINTs
	PCMSK0 = 0;
	PCMSK1 = 0;
	PCMSK2 = 0;

	//Enable Specific Pins
	PCMSK2 |= (1 << PCINT18);	// THRO - PIN2	PD2
	PCMSK2 |= (1 << PCINT20);	// ALIE - PIN4	PD4
	PCMSK2 |= (1 << PCINT23);	// ELEV - PIN7	PD7
	PCMSK0 |= (1 << PCINT0);	// RUDD - PIN8	PB0
	PCMSK0 |= (1 << PCINT1);	// GEAR - PIN9	PB1
	PCMSK0 |= (1 << PCINT2);	// AUX1 - PIN10	PB2


	// Enable Interrupts
	sei();
}




// ----- Interrupts ----- //

// PCINT[7:0]
ISR(PCINT0_vect){
	// RUDD Channel: =========================================
	//Input changed from 0 to 1 (Rising Edge)
	if(last_channel_value_RUDD == 0 && (PINB & B00000001) ){
		rise_time_RUDD = get_count_t1();
		last_channel_value_RUDD = 1;        //Remember current input state
		}
	//Input changed from 1 to 0 (Falling Edge)
	else if(last_channel_value_RUDD == 1 && !(PINB & B00000001)){
		fall_time_RUDD = get_count_t1();
		last_channel_value_RUDD = 0; //Remember current input state
		RUDD_pulse_width = fall_time_RUDD - rise_time_RUDD;
		}


	// GEAR Channel: =========================================
	//Input changed from 0 to 1 (Rising Edge)
	if(last_channel_value_GEAR == 0 && (PINB & B00000010) ){
		rise_time_GEAR = get_count_t1();
		last_channel_value_GEAR = 1;        //Remember current input state
		}
	//Input changed from 1 to 0 (Falling Edge)
	else if(last_channel_value_GEAR == 1 && !(PINB & B00000010)){
		fall_time_GEAR = get_count_t1();
		last_channel_value_GEAR = 0; //Remember current input state
		GEAR_pulse_width = fall_time_GEAR - rise_time_GEAR;
		}

	// AUX1 Channel: =========================================
	//Input changed from 0 to 1 (Rising Edge)
	if(last_channel_value_AUX1 == 0 && (PINB & B00000100) ){
		rise_time_AUX1 = get_count_t1();
		last_channel_value_AUX1 = 1;        //Remember current input state
		}
	//Input changed from 1 to 0 (Falling Edge)
	else if(last_channel_value_AUX1 == 1 && !(PINB & B00000100)){
		fall_time_AUX1 = get_count_t1();
		last_channel_value_AUX1 = 0; //Remember current input state
		AUX1_pulse_width = fall_time_AUX1 - rise_time_AUX1;
		}
}

// PCINT[14:8]
ISR(PCINT1_vect){

}

// PCINT[16:23]
ISR(PCINT2_vect){

	// THRO Channel: =========================================
	//Input changed from 0 to 1 (Rising Edge)
	if(last_channel_value_THRO == 0 && (PIND & B00000100) ){
		rise_time_THRO = get_count_t1();
		last_channel_value_THRO = 1;        //Remember current input state
		}
	//Input changed from 1 to 0 (Falling Edge)
	else if(last_channel_value_THRO == 1 && !(PIND & B00000100)){
		fall_time_THRO = get_count_t1();
		last_channel_value_THRO = 0; //Remember current input state
		THRO_pulse_width = fall_time_THRO - rise_time_THRO;
		}

	// ALIE Channel: =========================================
	//Input changed from 0 to 1 (Rising Edge)
	if(last_channel_value_ALIE == 0 && (PIND & B00010000) ){
		rise_time_ALIE = get_count_t1();
		last_channel_value_ALIE = 1;        //Remember current input state
		}
	//Input changed from 1 to 0 (Falling Edge)
	else if(last_channel_value_ALIE == 1 && !(PIND & B00010000)){
		fall_time_ALIE = get_count_t1();
		last_channel_value_ALIE = 0; //Remember current input state
		ALIE_pulse_width = fall_time_ALIE - rise_time_ALIE;
		}

	// ELEV Channel: =========================================
	//Input changed from 0 to 1 (Rising Edge)
	if(last_channel_value_ELEV == 0 && (PIND & B10000000) ){
		rise_time_ELEV = get_count_t1();
		last_channel_value_ELEV = 1;        //Remember current input state
		}
	//Input changed from 1 to 0 (Falling Edge)
	else if(last_channel_value_ELEV == 1 && !(PIND & B10000000)){
		fall_time_ELEV = get_count_t1();
		last_channel_value_ELEV = 0; //Remember current input state
		ELEV_pulse_width = fall_time_ELEV - rise_time_ELEV;
		}
}


