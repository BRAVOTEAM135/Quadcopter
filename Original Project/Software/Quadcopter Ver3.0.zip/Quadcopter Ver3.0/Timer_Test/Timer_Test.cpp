#include <Arduino.h>
#include "Radio.h"
/*
* ==============================================================
* ===== Defines =====
* ==============================================================

// =============================================================
/*
* ==============================================================
* ===== Variables =====
* ==============================================================
*/
volatile uint32_t T1_overflow_count = 0;
volatile uint32_t T1_timer = 0;

uint8_t flag = 0;
uint8_t last_channel_1 = 0;

uint32_t rising_time;
uint32_t falling_time;
volatile uint16_t pulse_width;



// =============================================================
/*
* ==============================================================
* ===== Function =====
* ==============================================================
*/
// ----- Init Timer 1 -----
// Timer one is used as timer for system. GetMicros and delays
void init_T1(){
	cli(); //Disable all interrupts

	// Initialize the Overflow counter variable
	T1_overflow_count = 0;

	// Clear Registers
	TCCR1A = 0;
	TCCR1B = 0;

	// TCCR1 - set WGM waveform generation mode
	// Fast PWM
	// TOP = OCR1A
	TCCR1A |= (1 << WGM10);
	TCCR1A |= (1 << WGM11);
	TCCR1B |= (1 << WGM12);
	TCCR1B |= (1 << WGM13);

	// set the prescaler. Clk/8
	TCCR1B |= (1 << CS11); // 0.5us tick

	// TIMSK - enable Output Compare A Match Interrupt
	TIMSK1 |= (1 << OCIE1A);

	// OCR1 - Output Compare Register
	OCR1A = 1999; // This is to give an interrupt every 1ms 0 - 1999 = 2000 ticks. 2000ticks * 0.5us = 1ms

	sei(); // Enable all Interrupts
}

// ----- Ticks 0.5us resolution ----
uint32_t ticks_T1(){
	uint8_t SREG_old = SREG; //take copy of AVR Status reg
	cli(); //Clear interrupts

	// TCNT1 - Timer/Counter Count Value. 16bit word
	uint16_t local_TCNT1 = TCNT1; // Take a local copy of the Timer/Counter Count

	// TIFR - Timer Interrupt Flag Register.
	// Bit 1 = OCFA (Output Compare A Match Flag)
	uint8_t local_TIFR = bitRead(TIFR1,1);

	// Check to see if overflowed while in this function
	if(local_TIFR){
		local_TCNT1 = TCNT1;
		T1_overflow_count++;
		TIFR1 |= (1 << OCF1A);
	}
	uint32_t ticks = local_TCNT1 + (T1_overflow_count * 2000); // Returns the number of ticks.
	sei(); // Set interrupts
	SREG = SREG_old;

	return ticks;
}

float micros_T1(){
	return ticks_T1() * 0.5;
}


// ----- Delay Milli Second -----
// NOTE: Not very accurate due to checking count and not isr
// Useful for debug
void delay_T1(int ms){
	// Initial value
	uint32_t start = T1_overflow_count;

	// Do While True
	while (T1_overflow_count < (start+ms)){}
}

/*
// Set up Pins for PinChange i.e. PWM Read
void init_PWMREAD(){
	// Clear interrupts
	cli();

	// Enable Pin Change Interrupt 0 [7:0]
	PCICR |= (0 << PCIE0);
	PCICR |= (0 << PCIE1);
	PCICR |= (1 << PCIE2);

	// Enable pin D2 (PCINT2) for interrupts
	PCMSK2 = 0;
	PCMSK2 |= (1 << PCINT18);

	PCMSK0 = 0;
	PCMSK1 = 0;

	// Enable Interrupts
	sei();
}
*/
Radio myRadio;
// ----- SETUP -----
void setup() {

	SREG |= (1 << 7);
	init_T1();

	Serial.begin(115200);
	pinMode(13, OUTPUT);
	pinMode(2, INPUT);

	//init_PWMREAD();
	myRadio.init_channels();

	PORTB = PORTB & B11011111; //pin 13 LOW
	//PORTB = PORTB | B00100000; //pin 13 HIGH
}

// ----- MAIN LOOP -----
void loop() {

	PORTB = PORTB & B11011111; //pin 13 LOW
	delay_T1(10);
	PORTB = PORTB | B00100000; //pin 13 HIGH
	delay_T1(10);

/*
	if(T1_timer == 0){
		if(flag == 0){
		Serial.print("(");
		Serial.print(ticks_T1());
		Serial.print(" -:- ");
		flag = 1;
		}

	}
	if(T1_timer == 500){
		//PORTB = PORTB ^ B00100000;
		Serial.print(ticks_T1());
		Serial.println(")");
		T1_timer = 0;
		flag = 0;

	}
*/
	/*
	// Called every 500ms
if (T1_timer == 20){
	cli();
	uint16_t local_pulse_width = pulse_width;
	sei();
	float f_local_pulse_width = local_pulse_width * 0.5;
	Serial.println(f_local_pulse_width);
	//Serial.println((f_local_pulse_width/2000) * 100.0); //Convert to Per
	/*
	if (local_pulse_width >= 3500 || local_pulse_width < 2500 ){
	Serial.println(local_pulse_width);
	Serial.println(bitRead(TIFR1,1));
	Serial.println("");
	}
	*/

	/*
	T1_timer = 0; // Reset the schedule counter
}
*/
	}


// ----- INTERUPT SERVICE ROUTINE -----
// This is called every 1ms
ISR(TIMER1_COMPA_vect){
	//PORTB = PORTB ^ B00100000;
	T1_overflow_count++;
	T1_timer++;
}
/*
ISR(PCINT2_vect){

	//Channel 1: Throttle =========================================
	//Input 2 changed from 0 to 1 (Rising Edge)
	if(last_channel_1 == 0 && (PIND & B00000100) ){
		rising_time = ticks_T1();
		PORTB = PORTB | B00100000; // Set Pin 13 HIGH
		last_channel_1 = 1;        //Remember current input state
		}
	//Input 2 changed from 1 to 0 (Falling Edge)
	else if(last_channel_1 == 1 && !(PIND & B00000100)){
		falling_time = ticks_T1();
		PORTB = PORTB & B11011111; // Set Pin 13 LOW
		last_channel_1 = 0; //Remember current input state
		pulse_width = falling_time - rising_time;
		}
	}

*/
