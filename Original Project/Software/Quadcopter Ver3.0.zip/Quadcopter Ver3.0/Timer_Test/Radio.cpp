/*
 * Radio.cpp
 *
 *  Created on: 12 Feb 2017
 *      Author: Kevin
 */
 #include "Arduino.h" /* Required to use the arduino libary */

#include "Radio.h"


Radio::Radio() {
	Radio::channel_value_THRO = 0;
	Radio::channel_value_ALIE = 0;
	Radio::channel_value_ELEV = 0;
	Radio::channel_value_RUDD = 0;
	Radio::channel_value_GEAR = 0;
	Radio::channel_value_AUX1 = 0;
}

void Radio::init_channels(){
	// Clear Interrupts
	cli();

	// Enable Pin Change Interrupts
	// Pin Change Interrupt 0 [7:0]
	// Pin Change Interrupt 1 [14:8]
	// Pin Change Interrupt 2 [23:16]
		PCICR |= (1 << PCIE0);
		PCICR |= (0 << PCIE1);
		PCICR |= (1 << PCIE2);

		// Clear all PCINTs
		PCMSK0 = 0;
		PCMSK1 = 0;
		PCMSK2 = 0;

		//Enable Specific Pins
		PCMSK2 |= (1 << PCINT18);	// THRO - PIN2
		PCMSK2 |= (1 << PCINT20);	// ALIE - PIN4
		PCMSK2 |= (1 << PCINT23);	// ELEV - PIN7
		PCMSK0 |= (1 << PCINT0);	// RUDD - PIN8
		PCMSK0 |= (1 << PCINT1);	// GEAR - PIN9
		PCMSK0 |= (1 << PCINT2);	// AUX1 - PIN10


		// Enable Interrupts
		sei();

}

uint16_t Radio::read_thro(){
	//Input changed from 0 to 1 (Rising Edge)
	if(last_channel_value_THRO == 0 && (PIND & B00000100) ){
		rise_time_THRO = get_count_t1();
		last_channel_value_THRO = 1;        //Remember current input state
		}
	//Input changed from 1 to 0 (Falling Edge)
	else if(last_channel_value_THRO == 1 && !(PIND & B00000100)){
		fall_time_THRO = get_count_t1();
		last_channel_value_THRO = 0; //Remember current input state
		THRO_pulse_width = fall_time_THRO - rise_time_THRO;
		}
	return THRO_pulse_width;
}

/*
// ----- Interrupts ----- //
// PCINT[7:0]
ISR(PCINT0_vect){

}

// PCINT[14:8]
ISR(PCINT1_vect){

}

// PCINT[16:23]
ISR(PCINT2_vect){
	//Channel 1: Throttle =========================================
}
*/

